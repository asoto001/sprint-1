const gastos = {
  mon: 31.55,
  tue: 66.12,
  wed: 99.9,
  thur: 60.21,
  fri: 41.50,
  sat: 89.99,
  sun: 53.88
}

const spanSuma = document.getElementById('sumass')

const valores = Object.values(gastos);

const total = valores.reduce((total, actual)=> total + actual, 0);
let resultado = 921 - total

console.log(total);
spanSuma.innerHTML = resultado;


